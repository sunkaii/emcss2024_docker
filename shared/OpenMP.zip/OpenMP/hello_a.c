#include <stdio.h>
int main()
{
        printf("hello(%d) ", ID);         
        printf("world(%d) \n", ID);     
}
