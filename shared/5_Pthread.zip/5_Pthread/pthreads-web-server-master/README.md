pthreads-web-server
===================

© Tommy Markley, Fall 2013

This is my C server project done for Operating Systems at St. Olaf College. 

============================================================================

The makefile included compiles both the client and server files with gcc. After you compile, you can configure your
port, log file name, and number of threads used in config.txt. Then, run your server and send HTTP request from the
client! Woo!
