1:利用makefile編譯
2:相關設定在config.txt，如thread個數、port、以及log檔案名稱
3:執行 ./server