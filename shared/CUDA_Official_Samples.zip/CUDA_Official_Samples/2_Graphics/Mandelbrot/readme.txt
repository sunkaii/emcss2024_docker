Sample: Mandelbrot
Minimum spec: SM 3.5

This sample uses CUDA to compute and display the Mandelbrot or Julia sets interactively. It also illustrates the use of "double single" arithmetic to improve precision when zooming a long way into the pattern. This sample uses double precision.  Thanks to Mark Granger of NewTek who submitted this code sample.!

Key concepts:
Graphics Interop
Data Parallel Algorithms
