Sample: simpleGLES_EGLOutput
Minimum spec: SM 3.5

Demonstrates data exchange between CUDA and OpenGL ES (aka Graphics interop). The program modifies vertex positions with CUDA and uses OpenGL ES to render the geometry, and shows how to render directly to the display using the EGLOutput mechanism and the DRM library.

Key concepts:
Graphics Interop
Vertex Buffers
3D Graphics
