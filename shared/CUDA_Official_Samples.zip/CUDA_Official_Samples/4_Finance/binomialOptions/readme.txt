Sample: binomialOptions
Minimum spec: SM 3.5

This sample evaluates fair call price for a given set of European options under binomial model.

Key concepts:
Computational Finance
