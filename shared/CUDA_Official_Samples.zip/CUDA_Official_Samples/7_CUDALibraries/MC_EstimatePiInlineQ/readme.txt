Sample: MC_EstimatePiInlineQ
Minimum spec: SM 3.5

This sample uses Monte Carlo simulation for Estimation of Pi (using inline QRNG).  This sample also uses the NVIDIA CURAND library.

Key concepts:
Random Number Generator
Computational Finance
CURAND Library
