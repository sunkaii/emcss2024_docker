Sample: batchCUBLAS
Minimum spec: SM 3.5

A CUDA Sample that demonstrates how using batched CUBLAS API calls to improve overall performance.

Key concepts:
Linear Algebra
CUBLAS Library
