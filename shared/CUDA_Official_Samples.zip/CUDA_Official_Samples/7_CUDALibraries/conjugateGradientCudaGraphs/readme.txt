Sample: conjugateGradientCudaGraphs
Minimum spec: SM 3.5

This sample implements a conjugate gradient solver on GPU using CUBLAS and CUSPARSE library calls captured and called using CUDA Graph APIs.

Key concepts:
Linear Algebra
CUBLAS Library
CUSPARSE Library
