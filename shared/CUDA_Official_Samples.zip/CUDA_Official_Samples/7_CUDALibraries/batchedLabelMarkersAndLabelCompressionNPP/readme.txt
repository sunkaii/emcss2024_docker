Sample: batchedLabelMarkersAndLabelCompressionNPP
Minimum spec: SM 3.5

An NPP CUDA Sample that demonstrates how to use the NPP label markers generation and label compression functions based on a Union Find (UF) algorithm including both
single image and batched image versions.

Key concepts:
Performance Strategies
Image Processing
NPP Library
Using NPP Batch Functions
