Sample: nvJPEG_encoder
Minimum spec: SM 3.5

A CUDA Sample that demonstrates single encoding of jpeg images using NVJPEG Library.

Key concepts:
Image Encoding
NVJPEG Library
