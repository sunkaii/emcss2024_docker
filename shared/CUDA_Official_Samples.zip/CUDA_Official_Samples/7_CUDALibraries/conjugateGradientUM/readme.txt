Sample: conjugateGradientUM
Minimum spec: SM 3.5

This sample implements a conjugate gradient solver on GPU using CUBLAS and CUSPARSE library, using Unified Memory

Key concepts:
Unified Memory
Linear Algebra
CUBLAS Library
CUSPARSE Library
