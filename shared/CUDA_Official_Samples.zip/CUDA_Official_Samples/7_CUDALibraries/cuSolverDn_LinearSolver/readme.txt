Sample: cuSolverDn_LinearSolver
Minimum spec: SM 3.5

A CUDA Sample that demonstrates cuSolverDN's LU, QR and Cholesky factorization.

Key concepts:
Linear Algebra
CUSOLVER Library
