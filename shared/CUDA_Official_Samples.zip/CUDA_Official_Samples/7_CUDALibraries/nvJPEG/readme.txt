Sample: nvJPEG
Minimum spec: SM 3.5

A CUDA Sample that demonstrates single and batched decoding of jpeg images using NVJPEG Library.

Key concepts:
Image Decoding
NVJPEG Library
