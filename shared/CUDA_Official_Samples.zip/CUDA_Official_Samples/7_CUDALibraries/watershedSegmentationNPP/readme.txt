Sample: watershedSegmentationNPP
Minimum spec: SM 3.5

An NPP CUDA Sample that demonstrates how to use the NPP watershed segmentation function.

Key concepts:
Performance Strategies
Image Processing
NPP Library
