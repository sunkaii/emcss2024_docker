Sample: simpleCUBLASXT
Minimum spec: SM 3.5

Example of using CUBLAS-XT library.

Key concepts:
CUBLAS-XT Library
