Sample: simpleCUBLAS_LU
Minimum spec: SM 3.5

CUDA sample demonstrating cuBLAS API cublasDgetrfBatched() for lower-upper (LU) decomposition of a matrix.

Key concepts:
CUBLAS Library
LU decomposition
