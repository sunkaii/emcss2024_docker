Sample: conjugateGradient
Minimum spec: SM 3.5

This sample implements a conjugate gradient solver on GPU using CUBLAS and CUSPARSE library.

Key concepts:
Linear Algebra
CUBLAS Library
CUSPARSE Library
