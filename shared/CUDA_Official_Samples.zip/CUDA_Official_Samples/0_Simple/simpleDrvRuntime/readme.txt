Sample: simpleDrvRuntime
Minimum spec: SM 3.5

A simple example which demonstrates how CUDA Driver and Runtime APIs can work together to load cuda fatbinary of vector add kernel and performing vector addition.

Key concepts:
CUDA Driver API
CUDA Runtime API
Vector Addition
