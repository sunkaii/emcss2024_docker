Sample: simplePrintf
Minimum spec: SM 3.5

This basic CUDA Runtime API sample demonstrates how to use the printf function in the device code.

Key concepts:
Debugging
