Sample: simpleCudaGraphs
Minimum spec: SM 3.5

A demonstration of CUDA Graphs creation, instantiation and launch using Graphs APIs and Stream Capture APIs.

Key concepts:
CUDA Graphs
Stream Capture
