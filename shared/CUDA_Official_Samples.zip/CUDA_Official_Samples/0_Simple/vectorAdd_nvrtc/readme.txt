Sample: vectorAdd_nvrtc
Minimum spec: SM 3.5

This CUDA Driver API sample uses NVRTC for runtime compilation of vector addition kernel. Vector addition kernel demonstrated is the same as the sample illustrating Chapter 3 of the programming guide.

Key concepts:
CUDA Driver API
Vector Addition
Runtime Compilation
