Sample: binaryPartitionCG
Minimum spec: SM 3.5

This sample is a simple code that illustrates binary partition cooperative groups and reduce within the thread block.

Key concepts:
Cooperative Groups
