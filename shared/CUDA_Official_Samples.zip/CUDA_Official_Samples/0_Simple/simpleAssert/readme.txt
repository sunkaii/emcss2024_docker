Sample: simpleAssert
Minimum spec: SM 3.5

This CUDA Runtime API sample is a very basic sample that implements how to use the assert function in the device code. Requires Compute Capability 2.0 .

Key concepts:
Assert
