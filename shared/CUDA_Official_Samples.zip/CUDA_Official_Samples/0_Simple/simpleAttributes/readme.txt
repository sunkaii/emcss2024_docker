Sample: simpleAttributes
Minimum spec: SM 3.5

This CUDA Runtime API sample is a very basic example that implements how to use the stream attributes that affect L2 locality. Performance improvement due to use of L2 access policy window can only be noticed on Compute capability 8.0 or higher.

Key concepts:
Attributes usage on stream
