Sample: simpleAWBarrier
Minimum spec: SM 7.0

A simple demonstration of arrive wait barriers.

Key concepts:
Arrive Wait Barrier
