Sample: memMapIPCDrv
Minimum spec: SM 3.5

This CUDA Driver API sample is a very basic sample that demonstrates Inter Process Communication using cuMemMap APIs with one process per GPU for computation. Requires Compute Capability 3.0 or higher and a Linux Operating System, or a Windows Operating System

Key concepts:
CUDA Driver API
cuMemMap IPC
MMAP
