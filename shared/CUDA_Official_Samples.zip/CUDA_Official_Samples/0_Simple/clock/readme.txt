Sample: clock
Minimum spec: SM 3.5

This example shows how to use the clock function to measure the performance of block of threads of a kernel accurately.

Key concepts:
Performance Strategies
