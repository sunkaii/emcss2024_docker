Sample: simpleTexture
Minimum spec: SM 3.5

Simple example that demonstrates use of Textures in CUDA.

Key concepts:
CUDA Runtime API
Texture
Image Processing
