Sample: simplePitchLinearTexture
Minimum spec: SM 3.5

Use of Pitch Linear Textures

Key concepts:
Texture
Image Processing
