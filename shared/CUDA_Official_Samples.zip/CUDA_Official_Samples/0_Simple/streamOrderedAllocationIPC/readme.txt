Sample: streamOrderedAllocationIPC
Minimum spec: SM 6.0

This sample demonstrates IPC pools of stream ordered memory allocated using cudaMallocAsync and cudaMemPool family of APIs.

Key concepts:
Performance Strategies
