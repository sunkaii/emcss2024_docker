Sample: streamOrderedAllocation
Minimum spec: SM 6.0

This sample demonstrates stream ordered memory allocation on a GPU using cudaMallocAsync and cudaMemPool family of APIs.

Key concepts:
Performance Strategies
