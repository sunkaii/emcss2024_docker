Sample: simpleIPC
Minimum spec: SM 3.5

This CUDA Runtime API sample is a very basic sample that demonstrates Inter Process Communication with one process per GPU for computation.  Requires Compute Capability 3.0 or higher and a Linux Operating System, or a Windows Operating System with TCC enabled GPUs

Key concepts:
CUDA Systems Integration
Peer to Peer
InterProcess Communication
